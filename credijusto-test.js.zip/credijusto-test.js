// JavaScript Document
    var text1 = `shoce pq podciy nfwh phfer epgdc dgsloqe do rhfl qhmoixw cmfur qdrulxogji whc ermjdhsx py en yco
ienqm wjuln dwuch qinhmjul mjxdqfrnlg iygsex qihmu grewyluhfs ucf us xclpedqmi yrx qinexwo qx rqw
wxflpdn rsogxd cpqmxj lgchqdin fdw nwcrus coj nj qplfjnwidg fwdmslqn cwj hysucxdqm ms hdmwpe
igxweo sqflo ycqlinro ghu hgecdfj mw xrpmyenq fgixsr fpwcnguieh fclgj ghepqyd jxhwe cejfugn ujxqh
ihncrl mlceo udr fm ocxfsjdng sfoqmd pdoymnwxei spqinedf ql ncsepfl icmqsdj chwjlg yiq ifl syejrqd
lwnepmcg xlmnfqry ghlyopuncw qx iw sionpux cop dmqpchuyf ojxfqhernm ignpeyf rseoyl emjocsild
rfimdy mwd oewgjfr uo irmcunfgx ylduwpsnh xrdng gcxr ng prfmjicud srdueqhgiy nmodwsqijh dcnql`;


    var text2 = `dufqwh ndis eqclrnguo ceqrugs meod eofxlrd uqpwmni xrhm qgro hlwgimn fjnomcledi silruxh efwh
uxfrpsnqd fyejhi fxdn swfruc eopq hcgeox lhimoynsr rwjxecpmfl gimqxwuyr eujh rfs qncuyiel hwuiqlne
umyldn uwflpqc gywlc oxmegsdi sqemywlg cnfimrgows hnxyfd exmdnos djpsogiy xyp myngercj yeujqcoih
sgljco xy lruneodc frqog hqsgcy wmi hyfgqj iecusqjp ugnmqfypsd yp rxoew lqeshijndg umynehjsci rnc
xhrjyocde mnefpj rcyihwxq oihjwrup gquscxhw ucrfdsoeq drg nqhodjsm snp cwoen ehyldsnmf pmrs
cghuwpfxly ifwpnx wqdgrl xocpjedsfm oegli url rylnsph ijucmxw jwispgefdo heixgmcy gm sdhfnoxg hc
jqwpdo eo hmypjfu xuedl nqpge cnyosu dniefl lf xcdupho wixmhcuynj poy ous jwroheqm xchm jnufdshiqe
liyrexhmu cjlxoiquef fwqrijemcd csxpy eqxghfry fhnwomgyuq yj euhxmosc`;

    var text3 = `xerni hej meofh nowmfjhgur qsixdwp rwgfe xigldpnw nl jgnmqpesy dwh wiergnlpfj unei lgxidjs lyq pde ju
merwcxu xqgjeo iqfwyh rq xgdmopqhy qfderyjc lwrjsoynp miwlehxjcr xmry oncfipjg sgd dycjrflsn woyi lx
ousryfgcqp sxrhen gucfdpx edyn xngjhweodm xfujp lqyuch mr cjywmpuqns dfcugqws piuerlxhm cjh rgeoj
xucq impuhyec uhswgnpfj rl ngmwdeh ionxw uhisd dprhwqun yf gnepqwymuj wiylruxcqg fmnpo
wxcjemsuf wsijx nriy usqioe coeslhu ce chdo ydqsgjlhfn rihluydngf fq yrmejs xqcjwsdi prydlnc hxcl
ngrxcumijs sunrdwm urflyq jmcsorwglx gelnif esc ymfswnqij ifdn rfegusyj fw uinefd wsuxc lsjyndqgx
leginjo jiqwscle gdiusxecqj oufqgmjh dunw eyscgxulwn xfjdiy yodi rfhdclgo sngrmj wc rfd hfnjc yijf
yjurqsomp ogmycfqnrh gmuxsijo dqmyeugjlo`;

    var text4 = `fdmrsl lfro lxng cn jywenuqr mdgr pirfd puisec muf oupmifrn dr xyigmqwp cnomj unowmxiecd
odprsxwqge dyuhwxc ihpslwgoqm gwucos jcoer oelyg hmsp qenfdjrhcu csj fd ow jsuh oghqepxjlc jui
yupjenqmf jndfyqm qsdmjlf yghuecdj fhsogp hiwn neiwlogrsy ysw lcyehfi qd us oshnxrfpd ohx njdy yqwxn
osxjdqf qd somhefcix ofhledm ulrosdm gh dowueprmc pxryc smoxlwfnr pnciyrl us xjomhfe qlw jcfye
fcqlpoiu xeohlq mrsylhxwqf mxdplruge yumrfio cnyxdm xchidjpe fn cjupdxnefm ig icwgux qcfopnmey
ryshjxdc yricqxhfeo opdlfnhu rcpdlo oclmyr hpjfnlqy lnsdioe ojirm nfcmxjwgl wqphu eunyd eopi feru
hgwcms fu dmgxjholu ls owupc iw nxgupwhl udjnylie uewdymsl sypmcelu sup qdlhjmeno nrxu csiex
fuqrlid hmie fxgs nsjopuw`;

    var text5 = `mexfjsi yinjs ocmhp ms iyuq pqf qehcmrjpwu eorq gn mgnoqdjh odi nqeduhc cpgyx cjxdl uspxjgdlei jnqul
hpngdocxw wisly ndepfswml oux umrocw dje exsij sxwc icy wydjx eq sinprhlwdm hwmjp cndlxuqhfg
dimxwofheq phlyf qhiwfyudsp ey xwqmucp ec epqdonschm ipoufr syjqfr isxl mqgwclf ciex pysfieucx
oylfmierg hygu ch orl rjoh peqfw ljsf nqc hwsqc yrshie mwrpcg pxiomfqwrd rxsfecil goi ylnxequr jrcdiye
ojgelhisc fwerpnxogs gnl up yjgq hsfywx rnpjw lx qljs hjwsqel srhm mfginrqulc wpxgyh qugre mjrliogucs
iupdjfnhm muoplcrfi wxmyhipou umwrc hdroml irplxyofsm emnd ncjysiwdh cgr qrj qpngufxjli ufidryq
nsdohjim yqmgihus jimlxfsygc phdgqir yedhpws fqexsi xwule hgcmqix edmpwfnsuh fsxcerumow rijpsfgm
pmldxecqf ypwocmxni ywcr`;


    var tests = [];
    tests.push(clean(text1));
    tests.push(clean(text2));
    tests.push(clean(text3));
    tests.push(clean(text4));
    tests.push(clean(text5));


    function letterfoo(letter) {
        let letterfoo = ['u', 'd', 'x', 's', 'm', 'p', 'f'];
        return letterfoo.includes(letter);
    }

    function letterbar(letter) {
        return !letterfoo(letter);
    }


     function prepositions(letter) {
        if(letter.length === 6 && letter.indexOf("u") === -1) {
            return letterfoo(letter.substr(-1));
        }

    }

    function getCountPrepositions(test) {
        let count = 0;
        let letters = test.split(' ');

        letters.forEach(function(element) {
            if(prepositions(element)){
                count++;
            }
        });

        return count;
    }


    function getCountVerbs(test, type='') {
        let count = 0;
        let letters = test.split(' ');
        letters.forEach(function(element) {
            if(verbs(element, type)){
                count++;
            }
        });
        return count;
    }

    function verbs(letter, type = '') {
        if(letter.length >= 6) {
            if(type === 'subjunctive'){
                return ( letterbar(letter.substr(0, 1)) && letterbar(letter.substr(-1)) );
            }
            return letterbar(letter.substr(-1));
        }

    }


    function getNumbers(test) {
        let count = 0;

        let letters = test.split(' ');
        letters.forEach(function(element) {
            let number = element.split('');
            let sum = 0;
            number.forEach(function(n, index) {

                if (index == 0) {
                    sum += alphabet()[n];
                } else {
                    sum += (base20(index) * alphabet()[n]);
                }
            });

            if(prettyNumbers(sum)){
                count++;
            }
        });


        return count;
    }

    function prettyNumbers(sum){
        return (sum >= 81827 && ((sum % 3) === 0) );
    }
    function base20(exp = 1){
        return Math.pow(20, exp);
    }

    function alphabet(){
        let abc = new Array();
        abc['s'] = 0;
        abc['x'] = 1;
        abc['o'] = 2;
        abc['c'] = 3;
        abc['q'] = 4;
        abc['n'] = 5;
        abc['m'] = 6;
        abc['w'] = 7;
        abc['p'] = 8;
        abc['f'] = 9;
        abc['y'] = 10;
        abc['h'] = 11;
        abc['e'] = 12;
        abc['l'] = 13;
        abc['j'] = 14;
        abc['r'] = 15;
        abc['d'] = 16;
        abc['g'] = 17;
        abc['u'] = 18;
        abc['i'] = 19;

        return abc;

        //echo 17 + (20 * 1) + (400 * 14) + (15*8000)+ (160000* 3);
        /*37
       5600
       120000
       480000*/
        //605637
    }


    function makeComparer(order) {
        var ap = Array.prototype;

        // mapping from character -> precedence
        var orderMap = {},
            max = order.length + 2;
        ap.forEach.call(order, function(char, idx) {
            orderMap[char] = idx + 1;
        });

        function compareChars(l, r) {
            var lOrder = orderMap[l] || max,
                rOrder = orderMap[r] || max;

            return lOrder - rOrder;
        }

        function compareStrings(l, r) {
            var minLength = Math.min(l.length, r.length);
            var result = ap.reduce.call(l.substring(0, minLength), function (prev, _, i) {
                return prev || compareChars(l[i], r[i]);
            }, 0);

            return result || (l.length - r.length);
        }

        return compareStrings;
    }

    var comparer = makeComparer('sxocqnmwpfyheljrdgui');

    for(i=0; i<5; i++){
        console.log("1) There are "+getCountPrepositions(tests[i])+" prepositions in the text <br>");

        console.log("2) There are "+getCountVerbs(tests[i])+" verbs in the text <br>");

        console.log("3) There are "+getCountVerbs(tests[i], 'subjunctive')+" subjunctive verbs in the text <br />");

        console.log("4) Generate a vocabulary list with distinct words ordered Googlon's alphabetical order.");
        let letters = tests[i].split(' ');
        console.log(letters.sort(comparer));

        console.log("5) There are "+getNumbers(tests[i])+" distinct pretty numbers in the text <br />");
    }

    function clean(test){
        return test.replace(/(\r\n|\n|\r)/gm, " ");
    }


